//MANEJADOR DE WEB
var express = require('express');
//PARA ACCEDER AL BODY
var bodyParser = require("body-parser");
///ENVIROMENT
var cfenv = require('cfenv');


//INSTANCIA DE WEB
var app = express();

///USE BODY PARSER
app.use(bodyParser.urlencoded({
  	extended:true
}));
// parse application/json
app.use(bodyParser.json());

///MOTOR DE VISTA PUGJS
app.set('view engine','pug');
app.use('/static', express.static('public'));

app.set('port', (process.env.PORT || 8080));



var mongoose = require("mongoose");

//mongodb://admin:FCVONVEPIEQMHKBO@sl-us-south-1-portal.16.dblayer.com:29883,sl-us-south-1-portal.14.dblayer.com:29883/compose?authSource=admin&ssl=true


// configuration ===============================================================
// load local VCAP configuration
var vcapLocal = null
if (require('fs').existsSync('./vcap-local.json')) {
  try {
    vcapLocal = require("./vcap-local.json");
    ////console.log("Loaded local VCAP", vcapLocal);
  } catch (e) {
    console.error(e);
  }
}


// get the app environment from Cloud Foundry, defaulting to local VCAP
var appEnvOpts = vcapLocal ? {
    vcap: vcapLocal
} : {}

var appEnv = cfenv.getAppEnv(appEnvOpts);

var appName;
if (appEnv.isLocal) {
    require('dotenv').load();
}
var catalog_url = process.env.CATALOG_URL;
var orders_url = process.env.ORDERS_URL;
////console.log("Catalog URL is", catalog_url);
////console.log("Orders URL is", orders_url);

////console.log("Variable MONGO: " + process.env.MONGODB_URI);

/*
var BD = process.env.MONGODB_URI || "mongodb://Localhost/daviplataV1";


*/

//HTTPS
app.enable('trust proxy');

app.use (function (req, res, next) {
  if (req.secure || process.env.BLUEMIX_REGION === undefined) {
    next();
  } else {
    ////console.log('redirecting to https');
    res.redirect('https://' + req.headers.host + req.url);
  }
});

var mongoDbUrl, mongoDbOptions = {};

////console.log("Es local ?????: ")
////console.log(appEnv.isLocal);

if (appEnv.isLocal) {
  ////console.log("Variable MONGO: " + process.env.MONGODB_URI);
  var BD = process.env.MONGODB_URI || "mongodb://horacio:EQ4MhUduh1CTS1Tp@cluster0-shard-00-00-qxkfa.mongodb.net:27017,cluster0-shard-00-01-qxkfa.mongodb.net:27017,cluster0-shard-00-02-qxkfa.mongodb.net:27017/corescotia?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true";
  mongoose.connect(BD);
}else{
/*
  var mongoDbCredentials = appEnv.getServiceCreds("daviplataV1") || appEnv.services["compose-for-mongodb"][0].credentials;

  if (mongoDbCredentials) {
      var ca = [new Buffer(mongoDbCredentials.ca_certificate_base64, 'base64')];
      mongoDbUrl = mongoDbCredentials.uri;
      mongoDbOptions = {
          mongos: {
              ssl: true,
              sslValidate: true,
              sslCA: ca,
              poolSize: 1,
              reconnectTries: 1
          }
      };
  } else if (process.env.MONGODB_URL) {
      mongoDbUrl = process.env.MONGODB_URL;
  } else {
      console.error("No MongoDB connection configured!");
  }

  ////console.log("Connecting to", mongoDbUrl);
  mongoose.connect(mongoDbUrl, mongoDbOptions); // connect to our database
  */
  mongoDbUrl = process.env.MONGODB_URI || "mongodb://horacio:EQ4MhUduh1CTS1Tp@cluster0-shard-00-00-qxkfa.mongodb.net:27017,cluster0-shard-00-01-qxkfa.mongodb.net:27017,cluster0-shard-00-02-qxkfa.mongodb.net:27017/corescotia?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true";
  console.log("Connecting to", mongoDbUrl);
  mongoose.connect(mongoDbUrl, mongoDbOptions); // connect to our database
}




//mongoose.connect(BD);



mongoose.Promise = require('bluebird');


//puerto
app.set('port', (process.env.PORT || 2000));
app.listen(app.get('port'), function() {
  	console.log('Node app is running on port puerto', app.get('port'));
});

require('./routes')(app);