const ConversacionHandler = require('./ConversacionHandler')
const AssitantHandler = require('./AssitantHandler')
var FacebookSender = require('../senders/FacebookSender')

module.exports.enviarTexto = function(evento){

	//console.log("Enviar a " + evento.sender.id + ": " + evento.message.text)

	ConversacionHandler.obtenerConversacion(1,evento.sender.id,function(error,conversacion){
		if (error) {
			//console.log("Error FacebookHandlerText:")
			//console.log(error)
		}else{
			if (conversacion) {
				AssitantHandler.enviar(conversacion, evento.message.text, function(error,response){
					if (error) {
						//console.log(error)
					}else{

						qs = {
							recipient: {
								id: evento.sender.id
							},
							"message": {
								"text": response
							}
						}

						//console.log("Respuesta a enviar")
						//console.log(response)

						FacebookSender.enviarMensaje(qs,function(error,mensaje){
							if (error) {
								//console.log("Error FacebookHandlerText enviarTexto")
								//console.log(error)
							}else{
								
							}
						})
					}
				})
			}else{
				//console.log("Error FacebookHandlerText: No se encontro conversación")
			}
		}
	})

}