const AssitantHandler = require('./AssitantHandler')
const VisionHandler = require('./VisionHandler')
var FacebookSender = require('../senders/FacebookSender')
const ConversacionHandler = require('./ConversacionHandler')

module.exports.enviarFoto= function(evento){

	//console.log("Enviar: ")
	//console.log(typeof evento.message.attachments)

	evento.message.attachments.forEach((adjunto) => {
		console.log("adjunto")
		console.log(adjunto)
		if (adjunto.type == 'image') {
			procesarImagen(adjunto,evento,function(error,data){


				ConversacionHandler.obtenerConversacion(1,evento.sender.id,function(error,conversacion){
					if (error) {
						//console.log("Error FacebookHandlerText:")
						//console.log(error)
					}else{
						if (conversacion) {

							AssitantHandler.enviar(conversacion, data, function(error,response){
								if (error) {
									//console.log(error)
								}else{

									qs = {
										recipient: {
											id: evento.sender.id
										},
										"message": {
											"text": response
										}
									}

									//console.log("Respuesta a enviar en foto")
									//console.log(response)

									FacebookSender.enviarMensaje(qs,function(error,mensaje){
										if (error) {
											//console.log("Error FacebookHandlerText enviarTexto")
											//console.log(error)
										}else{
											
										}
									})
								}
							})
						}else{
							//console.log("Error FacebookHandlerText: No se encontro conversación")
						}
					}
				})

			})
		}
		if (adjunto.type == 'file') {
			procesarArchivo(adjunto,evento,function(error,data){

			})
		}
		if (adjunto.type == 'location') {
			procesarLocation(adjunto,evento,function(error,data){

			})
		}
	})

}

function procesarImagen(adjunto,evento,cb){
	
	//console.log("Procesar adjunto")
	//console.log(adjunto)

	VisionHandler.clasificarImagen(adjunto.payload.url,evento.sender.id,function(error,data){
		if (error) {
			//console.log(error)
			cb(error, null)
		}else{
			//console.log("Clasificar imagen")
			cb(null, data)
		}
	})

}

function procesarArchivo(adjunto,evento,cb){
	
}

function procesarLocation(adjunto, evento, cb){
	console.log("Procesar location")
}