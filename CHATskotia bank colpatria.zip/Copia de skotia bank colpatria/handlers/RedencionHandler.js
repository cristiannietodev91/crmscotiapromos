
var promotion = require('../models/promotion')
var usuarios = require('../models/usuarios')

var Promise = require("bluebird");
Promise.promisifyAll(require('mongoose'));


exports.consultarUsuarioYPromocion = function(conversacion,cb){

	var promesas = [promotion.findOne({promotionId: conversacion.context.codigoPromocion}),usuarios.findOne({identificacion: conversacion.context.cedula})]



	Promise.all(promesas).then(function(arre){
		console.log("Despues de promesas");
		console.log(arre.length);
		console.log(arre)
		if (arre[1] == null) {
			//NO EXISTE EL USUARIO
			cb(null,"No estas en el sistema, por favor llama por teléfono")
		}else{
			if (arre[0] == null) {
				//NO EXISTE LA PROMOCIÓN
				cb(null,"Parece que esa promoción no existe en el sistema")
			}else{
				//EXISTEN AMBOS
				cb(null, "Encontré esta promoción, confirma si es\n https://004e2d45.ngrok.io/beneficio/promotioncode/" + arre[0].promotionId)
			}
		}
	
	});

}