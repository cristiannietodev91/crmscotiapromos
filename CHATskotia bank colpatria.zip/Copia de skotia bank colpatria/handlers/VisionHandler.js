var VisualRecognitionV3 = require('watson-developer-cloud/visual-recognition/v3');
var fs = require('fs');
var request = require('request');
const constantes = require('../constantes')

var visualRecognition = new VisualRecognitionV3({
	url: 'https://gateway.watsonplatform.net/visual-recognition/api',
	version: '2018-03-19',
	iam_apikey: constantes.VISUAL_RECOGNITION_APIKEY
});

exports.clasificarImagen = function(url,nombre,cb){

	var nameImg = nombre + "_" + Date.now() + ".jpg"

	var nombreimg = "public/" + nameImg

	download(url, nombreimg, function(){

		//console.log("termino")

		var images_file= fs.createReadStream(nombreimg);
		//console.log("Paso fs")
		
		//var ruta = "https://scontent.xx.fbcdn.net/v/t1.15752-9/41867120_979866022216072_4545499344035381248_n.jpg"
		//var images_file= fs.createReadStream(ruta);

		var owners = ["me","IBM"];
		var threshold = 0.6;

		var params = {
			images_file: images_file,
			threshold: threshold,
			owners: owners,
			accept_language: "es"
		};

		visualRecognition.classify(params, function(err, response) {
	  		if (err){
	  			////console.log("Error clasificacion")
	    		////console.log(err);
	    		cb(err,null)
	    	}
	  		else{
	  			////console.log("REspuesta clasificacion")
	    		////console.log(JSON.stringify(response, null, 2))
	    		clasificarRespuesta(response, function(error,clasificacion){
	    			cb(null,clasificacion)
	    		})
	    	}
		});

	})

	

}

function clasificarRespuesta(respuesta,cb){
	var imagen = respuesta.images[0]
	//console.log(imagen.image)
	var clasificador_documentos = getClassifier("DefaultCustomModel_161471290",imagen.classifiers)
	var clasificador_IBM = getClassifier("default",imagen.classifiers)

	////console.log("clasificador_documentos")
	////console.log(clasificador_documentos)

	////console.log("clasificador_IBM")
	////console.log(clasificador_IBM)


	if (clasificador_documentos.classes.length > 0) {
		var maxPropio = obtenerCalificacionMasAlta(clasificador_documentos.classes)
	}
	if (clasificador_IBM.classes.length > 0) {
		var maxIBM = obtenerCalificacionMasAlta(clasificador_IBM.classes)
	}

	//console.log("Max propio")
	//console.log(maxPropio)
	//console.log("Max IBM")
	//console.log(maxIBM)

	if (maxPropio != null && maxPropio.score > 0.9) {
		//console.log("ES cedula")
		cb(null, "CEDULA_ARCHIVO " + imagen.image)
	}else{
		//console.log("No es cedula")
		cb(null, imagen.image)
	}
	
}

function obtenerCalificacionMasAlta(clases){
	var maximo = clases[0]
	for(var i = 0; i < clases.length ; i++){
		if (clases[i].score > maximo.score) {
			maximo = clases[i]
		}
	}
	return maximo
}

function getClassifier(nombre,clasificadores){
	for(var i = 0 ; i < clasificadores.length ; i++){
		if (clasificadores[i].classifier_id == nombre) {
			return clasificadores[i]
		}
	}
	return null
}

var download = function(uri, filename, callback){

  	request.head(uri, function(err, res, body){

    	//console.log('content-type:', res.headers['content-type']);
    	//console.log('content-length:', res.headers['content-length']);

    	request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);

  	});
};