
const AssitantHandler = require('./AssitantHandler')
const VisionHandler = require('./VisionHandler')
var FacebookSender = require('../senders/FacebookSender')
const ConversacionHandler = require('./ConversacionHandler')


module.exports.enviarLocation = function(evento){


}