
const constantes = require('../constantes')
var Conversacion = require("../models/Conversacion")
var randomstring = require("randomstring");


exports.obtenerConversacion = function(tipo,id,cb){

	console.log("En obtenerConversacion recibio tipo: " + tipo)

	var busca = obtenerBuscaPorTipo(tipo,id)

	console.log("Busca conversacion: ")
	console.log(busca)

	buscarConversacion(busca,function(error,conversacion){
		if (error) {
			cb(error,null)
		}else{
			if (conversacion) {
				conversacion.ultimoMensajeRecibido = Date.now()
				conversacion.save()
				cb(null,conversacion)
			}else{

				crearConversacion(busca,function(error,conversacion){
					if (error) {
						cb(error,null)
					}else{
						if (conversacion) {
							cb(null,conversacion)
						}else{
							cb({"Error":"No se pudo crear la conversacion"})
						}
					}
				})
			}
		}
	})
}

function obtenerBuscaPorTipo(tipo,id){
	return { FBSender : id}
}


function buscarConversacion(dict,cb){

	Conversacion
	.findOne(dict)
	.populate("ultimoMensajeAAsesor")
	.exec(function(error,conversacion){
		if (error) {
			cb(error,null)
		}else{
			cb(null,conversacion)
		}
	})

}

function crearConversacion(dict,cb){

	var codigoLetras = randomstring.generate({
  		charset: "ABCDEFGHIJKLMNOPQRST",
  		length: 3
	});
	var codigoNumeros = randomstring.generate({
  		charset: "0123456789",
  		length: 3
	});

	console.log("Generado " + codigoLetras + " - " + codigoNumeros)

	dict.context = {
		"timezone": "America/Bogota",
		"aceptoTerminos": false,
		celCode: codigoLetras + codigoNumeros
	}

	console.log("Crear conversación con: ")
	console.log(dict)

	Conversacion.create(dict,function(error,conversacion){
		if (error) {
			cb(error,null)
		}else{
			cb(null,conversacion)
		}
	})

}
