const constantes = require('../constantes')
var TipificacionRecord = require("../models/TipificacionRecord")
const RedencionHandler = require('./RedencionHandler')

var smsSender = require('../senders/smsSender')

var ConversationV1 = require('watson-developer-cloud/conversation/v1');
var conversation = new ConversationV1({
  	username: constantes.CONVERSATION_USERNAME,
  	password: constantes.CONVERSATION_PASSWORD,
  	version_date: ConversationV1.VERSION_DATE_2017_05_26
});

var SolicitudTarjeta = require("../models/SolicitudTarjeta")

exports.enviar = function(conversacion,texto,cb){

	conversation.message({
		input: {
			text: texto
		},
		workspace_id: constantes.CONVERSATION_WORKSPACE,
		context: conversacion.context
	}, function(error, response) {
		if (error) {
			console.log(error)
		}else{
			console.log("----------------- RESPUESTA WATSON ----------------------")
			console.log(response)
			console.log("END ----------------- RESPUESTA WATSON ----------------------")

			console.log(obtenerTextoParaResponderAUsuario(response))

			if (obtenerTextoParaResponderAUsuario(response).indexOf("envíe un código") > -1) {
				enviarCodigoConversacion(conversacion)
			}else{
				console.log("El index")
				console.log(obtenerTextoParaResponderAUsuario(response).indexOf("envíe un código"))
			}

			if (response.intents != null && response.intents.length > 0) {
				handleIntents(conversacion,response.intents,texto)
			}
			if (response.output != null && response.output.nodes_visited != null && response.output.nodes_visited.length > 0) {
				for (var i = 0 ; i < response.output.nodes_visited.length ; i++) {
					if (response.output.nodes_visited[i] == 'En otras cosas') {
						////////console.log(response)
						handleEntrOtrasCosas(conversacion,response.intents,texto)
					}
				}
			}


			if (existeComando(response)) {
				handleCommand(conversacion,response,1,function(error,data){
					if (error) {
						cb(error,null)
					}else{
						cb(null,data)
					}
				})
				cb(null,obtenerTextoParaResponderAUsuario(response))
			}else{
        		console.log("No existe el comando")
				conversacion.context = response.context
				conversacion.save()
				cb(null,obtenerTextoParaResponderAUsuario(response))
			}
		}
	})
}

function enviarCodigoConversacion(conversacion){
	console.log("Voy a enviar el código")
	var mensaje = "Su código para autenticar en el canal es " + conversacion.context.celCode
	console.log(mensaje)
	if (conversacion.context.celCode != conversacion.context.codigocel) {
		smsSender.enviarMensaje(conversacion.context.celular, mensaje, function(error, data){

		})
	}
	
}

function existeComando(respuestaWatson){
	if (respuestaWatson.output != null && respuestaWatson.output.command != null) {
		return true
	}
	return false
}

function obtenerTextoParaResponderAUsuario(respuestaWatson){
	var msg = ""
	for(var i = 0; i < respuestaWatson.output.text.length; i++){
		msg += respuestaWatson.output.text[i] + "\n\r"
	}
  //console.log("La respuesta de Watson hacia el cliente en obtenerTextoParaResponderAUsuario es: ")
  //console.log(msg);
	return msg
}

function handleCommand(conversacion,respuesta,origen,cb){

	//////console.log("Existe el comando: "+respuesta.output)

	switch(respuesta.output.command){
		case "COMUNICAR_CON_ASESOR":

			//////console.log("Caso COMUNICAR_CON_ASESOR")

			conversacion.cedula = respuesta.context.cedula
			conversacion.context = respuesta.context
			conversacion.save()

      serviciosSC.existeUsuarioEnDaviplata(respuesta.context.cedula,function(existe){
        if (existe == true) {
          AsesorHandler.obtenerDesborde(io,conversacion,origen,function(error,desborde){
            if (error) {
              //////console.log(error)
              //cb(error,null)
              var msj = obtenerTextoParaResponderAUsuario(respuesta) + "No se puede realizar en este momento, intente mas tarde"
              cb(null,msj)
              AsesorHandler.nuevoAbandono(conversacion,origen)
            }else{
              if (desborde) {
                var msg = obtenerTextoParaResponderAUsuario(respuesta)
                //msg += "¿en que puedo ayudarle?"
                conversacion.context = respuesta.context
                conversacion.comunicarAsesor = true
                conversacion.save()
                cb(null,msg)
              }else{
                cb({"ERROR":"NO TRAJO DESBORDE"},null)
              }

            }
          })
        }else{
          cb(null,"En este momento solo se puede atender cedulas que estan registradas en Daviplata")
        }
      })

		break
		case "ELIMINAR_DATOS":
			Conversacion.deleteMany({_id: conversacion._id})
			.exec(function(error){
				if (error) {
					//////console.log(error)
					cb(null,"No he podido eliminar los datos")
				}else{
					Desborde.deleteMany({conversacion: conversacion._id})
					.exec(function(error){
						if (error) {
							//////console.log(error)
							cb(null,"No he podido eliminar los datos (2)")
						}else{
							cb(null,"Ya elimine los datos")
						}
					})
				}
			})
		break
		case "TRAMITAR_SOLICITUD":
			console.log("Tramitar la solicitud")
			conversacion.context = respuesta.context
			conversacion.save()
			SolicitudTarjeta.create({
				conversacion: conversacion._id,
			},function(error,solicitud){
				if (error) {
					console.log(error)
				}
			})
		break
		case "BUSCAR_PUNTOS_Y_PROMOCION":
			console.log("Buscar puntos y promociones")
			conversacion.context = respuesta.context
			conversacion.save()
			RedencionHandler.consultarUsuarioYPromocion(conversacion,function(error,data){
				cb(error,data)
			})
		break
	}
}

function handleIntents(conversacion,intents,mensaje){
	//////console.log(intents)
	TipificacionRecord.create({
		tipificacion: intents[0].intent,
		confianza: intents[0].confidence,
		conversacion: conversacion._id,
		mensaje: mensaje
	},function(error,conversacion){
		if (error) {
			//////console.log(error)
		}else{
			////////console.log("OK")
		}
	})
}

function handleEntrOtrasCosas(conversacion,intents,mensaje){
	//////console.log("entre otras cosas")
	//////console.log(intents)
	TipificacionRecord.create({
		tipificacion: "NO_ENTIENDE",
		confianza: 0,
		conversacion: conversacion._id,
		mensaje: mensaje
	},function(error,conversacion){
		if (error) {
			//////console.log(error)
		}else{
			////////console.log("OK")
		}
	})
}