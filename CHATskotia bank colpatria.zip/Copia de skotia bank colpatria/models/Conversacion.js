var mongoose = require('mongoose');
var Schema   = mongoose.Schema;



var ConversacionSchema = new Schema({

	FBSender:{
		type: String
	},
	cedula:{
		type:String
	},
	celular:{
		type:String
	},
	context:{
		type: Schema.Types.Mixed
	}
	
},
{
	timestamps: true,
    toObject: {
      	virtuals: true
    },
 	toJSON: {
      	virtuals: true
    }
})


module.exports = mongoose.model("Conversacion",ConversacionSchema);
