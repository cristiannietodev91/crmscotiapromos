var mongoose = require('mongoose');
var Schema   = mongoose.Schema;



var SolicitudTarjetaSchema = new Schema({
	
	conversacion: {
		type:Schema.Types.ObjectId,
		ref:'Conversacion',
		required:true
	},
	estado: {
		//finalizado: true
		type: Boolean,
		default: false
	},
	respuesta: {
		//aprobado true,
		type: Boolean,
		default: false
	}

})
module.exports = mongoose.model("SolicitudTarjeta",SolicitudTarjetaSchema);