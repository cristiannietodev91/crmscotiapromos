var mongoose = require('mongoose');
var Schema   = mongoose.Schema;



var TipificacionRecordSchema = new Schema({

	fecha:{
		type: Date,
		default: Date.now
	},
	tipificacion:{
		type: String,
		required: true
	},
	confianza:{
		type: Number
	},
	conversacion:{
		type:Schema.Types.ObjectId,
		ref:'Conversacion',
		required:true
	},
	mensaje:{
		type: String,
		required: true
	}

},
{
	timestamps: true,
    toObject: {
      	virtuals: true
    },
 	toJSON: {
      	virtuals: true
    }
})
module.exports = mongoose.model("TipificacionRecord",TipificacionRecordSchema);