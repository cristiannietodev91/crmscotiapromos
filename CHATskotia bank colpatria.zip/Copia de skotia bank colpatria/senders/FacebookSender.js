const request = require('request')
const constantes = require('../constantes')


exports.enviarMensaje = function(qs,cb){

	////console.log("enviarAFacebook el mensaje: " + qs.message)
	////console.log("enviarAFacebook al recipient: " + qs.recipient.id)


	qs.access_token = constantes.TOKEN_ACCESO_PAGINA
	qs.method = 'POST'


	request({
		url: 'https://graph.facebook.com/v2.6/me/messages',
		qs:qs	
					
	    },function(error,response){
	    	if (error) {
	    		////console.log("Error de respuesta facebook ")
	    		////console.log(error)
	    		cb(error,null)
	    	}else{
	    		////console.log("respuesta facebook ")
	    		////console.log(response.body)
	    		cb(null,response.body)
	    	}
	});
}
