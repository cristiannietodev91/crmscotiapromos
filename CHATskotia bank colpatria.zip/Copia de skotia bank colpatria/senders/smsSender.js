

const request = require('request')
const constantes = require('../constantes')

exports.enviarMensaje = function(celular,mensaje,cb){


	var auth = new Buffer(constantes.ALDEAMO_USER + ':' + constantes.ALDEAMO_PASSWORD).toString('base64');

	var url = encodeURI("https://apismsi.aldeamo.com/SmsiWS/smsSendGet?mobile=" + celular + "&country=57&message=" + remplazarCaracteres(mensaje) + "&messageFormat=1")

	request({
		method: 'GET',
		url: url,
		headers:{
			Authorization: 'Basic ' + auth,
			'cache-control': 'no-cache'
			}
    },function(error,respuestaAldeamo){
    	if (error) {
    		console.log("Error enviar")
    		console.log(error)
    		cb(error,null)
    	}else{
    		console.log("Enviado")
    		console.log(JSON.parse(respuestaAldeamo.body))
    		cb(null,JSON.parse(respuestaAldeamo.body))
    	}
    })
}


function remplazarCaracteres(cadena){

    cadena = cadena.replace(/á/g , "a")
    cadena = cadena.replace(/é/g , "e")
    cadena = cadena.replace(/í/g , "i")
    cadena = cadena.replace(/ó/g , "o")
    cadena = cadena.replace(/ú/g , "u")

    cadena = cadena.replace(/Á/g , "A")
    cadena = cadena.replace(/É/g , "E")
    cadena = cadena.replace(/Í/g , "I")
    cadena = cadena.replace(/Ó/g , "O")
    cadena = cadena.replace(/Ú/g , "U")

    cadena = cadena.replace(/¿/g , " ")
    cadena = cadena.replace(/¡/g , " ")

    return cadena
}
