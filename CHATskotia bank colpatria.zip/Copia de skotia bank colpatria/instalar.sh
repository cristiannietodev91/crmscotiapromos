npm install --save express
npm install --save mongoose
npm install --save body-parser
#npm install --save connect-flash
npm install --save connect-mongo
#npm install --save express-session
#npm install --save pug
npm install --save moment
npm install --save randomstring

#paginacion
#npm install --save mongoose-middleware

#INSTALACION DE AWS
#npm install --save aws-sdk
#npm install --save multer
#npm install --save multer-s3

#ENVIO DE CORREOS
#npm install --save nodemailer

#TIEMPO REAL
#npm install --save socket.io

#CHATBOTS
npm install --save watson-developer-cloud
npm install --save request
npm install --save randomstring
npm install --save format-currency
npm install --save fb-messenger
npm install --save b64url

#WATSON CLOUD
#npm install --save cfenv
#npm install --save dotenv

