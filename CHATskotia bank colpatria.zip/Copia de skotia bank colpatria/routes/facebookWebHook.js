const constantes = require('../constantes')
const FacebookHandlerText = require('../handlers/FacebookHandlerText')
const FacebookHandlerFoto = require('../handlers/FacebookHandlerFoto')

module.exports = function(app){

	app.get("/facebook/webhook",function(req,res){

		if (req.query['hub.mode'] && req.query['hub.verify_token'] === constantes.TOKEN_PREGUNTA_FACEBOOK) {
		    res.status(200).send(req.query['hub.challenge']);
		} else {
		    res.status(403).end();
		}
	})

	app.post("/facebook/webhook",function(req,res){
		let body = req.body;
		console.log("Hola webhook")
		console.log(body)

		if (body.object === 'page') {
			
			//console.log(body.entry);
			body.entry.forEach((entry) => {
				entry.messaging.forEach((event) => {
					console.log("Event: ")
					console.log(event)

					if (event.message.text != null && event.message.text != undefined) {

						FacebookHandlerText.enviarTexto(event)

					}else if(event.message.attachments != null && event.message.attachments != undefined && event.message.attachments.length > 0){
						FacebookHandlerFoto.enviarFoto(event)
					}


				})
			})

		}		


		res.status(200).send('EVENT_RECEIVED');

	})


}