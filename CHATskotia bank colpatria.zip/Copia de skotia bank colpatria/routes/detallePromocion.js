
var promotion = require("../models/promotion")


module.exports = function(app){

	app.get("/beneficio/id/:id",function(req,res){

		promotion.findOne({_id: req.params.id},function(error,promotion){
			if (error) {
				res.json(error)
			}else{
				res.render("index",{
					promocion: promotion
				})
			}
		})

	})

	app.get("/beneficio/promotioncode/:code",function(req,res){

		promotion.findOne({promotionId: req.params.code},function(error,promotion){
			if (error) {
				res.json(error)
			}else{
				console.log("promocion")
				console.log(promotion)
				res.render("index",{
					promocion: promotion
				})
			}
		})

	})

}